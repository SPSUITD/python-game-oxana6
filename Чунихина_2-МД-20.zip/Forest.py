import pygame
import random
import os

pygame.init()

img = r"C:\...\...\...\Forest\Images" #Указать путь к Images.

win = pygame.display.set_mode((500, 500))
pygame.display.set_caption("Forest")

script_dir = os.path.dirname('Obstacles')
rel_path = img
abs_file_path = os.path.join(script_dir, rel_path)

current_file = r"\vetka.png"
vetkaimg = pygame.image.load(abs_file_path + current_file)
current_file = r"\smallshiska.png"
smShiskaimg = pygame.image.load(abs_file_path + current_file)
current_file = r"\shiska.png"
shiskaimg = pygame.image.load(abs_file_path + current_file)

rel_path = img
script_dir = os.path.dirname('Powerups')
abs_file_path = os.path.join(script_dir, rel_path)

current_file = r"\grib.png"
heartimg = pygame.image.load(abs_file_path + current_file)

abs_file_path = os.path.join('Backgrounds', img)
bg = pygame.image.load(abs_file_path + r"\background.jpg")

rel_path = img
script_dir = os.path.dirname('Player')
abs_file_path = os.path.join(script_dir, rel_path)

char = pygame.image.load(abs_file_path + r'\standing.png')

walkRight = [pygame.image.load(abs_file_path + r'\R1.png'), pygame.image.load(abs_file_path + r'\R2.png'),
             pygame.image.load(abs_file_path + r'\R3.png')]
walkLeft = [pygame.image.load(abs_file_path + r'\L1.png'), pygame.image.load(abs_file_path + r'\L2.png'),
            pygame.image.load(abs_file_path + r'\L3.png')]

clock = pygame.time.Clock()


class Character(object):
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.v = 5
        self.left, self.right = False, False
        self.standing = True
        self.walkCount = 0
        self.health = 10
        self.hitbox = (self.x - 2, self.y -2, 72, 63)
        self.alive = True

    def draw(self, win):
        if self.alive:

            if self.walkCount + 1 >= 3:
                self.walkCount = 0

            if not (self.standing):
                if self.left:
                    win.blit(walkLeft[self.walkCount], (self.x, self.y))
                    self.walkCount += 1
                elif self.right:
                    win.blit(walkRight[self.walkCount], (self.x, self.y))
                    self.walkCount += 1

            else:
                win.blit(char, (self.x, self.y))

            self.hitbox = (self.x - 2, self.y -2, 72, 63)

            pygame.draw.rect(win, (22, 26, 30), (self.hitbox[0], self.hitbox[1] - 25, 50, 10))
            pygame.draw.rect(win, (255, 0, 0), (self.hitbox[0], self.hitbox[1] - 25, 50 - (5 * (10 - self.health)), 10))

        else:
            font = pygame.font.SysFont('aria', 30, True)
            over = font.render('GAME OVER', 1, (0, 0, 0))
            win.blit(over, (290, 350))


class Block(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.v = 10
        self.falling = True

    def draw(self, win):
        if self.y < 500:
            win.blit(self.image, (self.x, self.y))
            self.y += self.v
        else:
            self.falling = False
    

class Shishka(Block):
    def __init__(self, x, y):
        Block.__init__(self, x, y)
        self.v = 10
        self.image = shiskaimg
        self.hitbox = (self.x, self.y - 10, 69, 80)
        self.id = "SHISKA"

    def draw(self, win):
        Block.draw(self,win)
        self.hitbox = (self.x, self.y - 10, 69, 80)


class SmallShishka(Block):
    def __init__(self, x, y):
        Block.__init__(self, x, y)
        self.v = 15
        self.image = smShiskaimg
        self.hitbox = (self.x, self.y - 10, 55, 65)
        self.id = "SMSHISKA"
    
    def draw(self,win):
        Block.draw(self, win)
        self.hitbox = (self.x, self.y - 10, 55, 65)


class Vetka(Block):
    def __init__(self, x, y):
        Block.__init__(self, x, y)
        self.v = 5
        self.image = vetkaimg
        self.hitbox = (self.x, self.y - 20, 163,100)
        self.id = "VETKA"

    def draw(self, win):
        Block.draw(self, win)
        self.hitbox = (self.x, self.y - 5, 163, 100)


class Powerup(object):
    def __init__(self, x):
        self.x = x
        self.y = 400
        self.image = None
        self.time = 270
        self.appear = True

    def draw(self, win):
        if self.appear:
            if self.time > 0:
                win.blit(self.image, (self.x, self.y))
            else:
                self.appear = False
            self.time -= 1


class Grip(Powerup):
    def __init__(self, x):
        Powerup.__init__(self, x)
        self.increase = 1
        self.image = heartimg
        self.id = "heart"
        self.hitbox = (self.x, self.y, 72, 60)

    def draw(self, win):
        Powerup.draw(self, win)
        self.hitbox = (self.x, self.y, 72, 60)


def drawWindow():
    win.blit(bg, (0,0))
    ulitka.draw(win)

    if ulitka.alive:
        for o in objects:
            o.draw(win)
        for p in powerups:
            p.draw(win)

        font = pygame.font.SysFont('arial', 30, True)
        text = font.render('Счёт: ' + str(score), 1, (0,0,0))
        win.blit(text, (350, 10))
                       
    else:
        font = pygame.font.SysFont('arial', 30, True)
        text = font.render('Счёт: ' + str(score), 1, (0,0,0))
        win.blit(text, (290, 400))

    pygame.display.update()
                         

ulitka = Character(250, 400, 68, 60)
print(type(ulitka))

objects, powerups = [], []
run = True
max_length, score, cooldown, interval = 0, 0, 0, 27

while run and ulitka.alive:

    clock.tick(27)

    center_x = (ulitka.hitbox[0] + (ulitka.hitbox[0] + ulitka.hitbox[2]))//2
    center_y = (ulitka.hitbox[1] + (ulitka.hitbox[1] + ulitka.hitbox[3]))//2

    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            run = False

    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT] and ulitka.x > 0:
        ulitka.x -= ulitka.v
        ulitka.left, ulitka.right = True, False
        ulitka.standing = False
    elif keys[pygame.K_RIGHT] and ulitka.x < 500 - ulitka.width:
        ulitka.x += ulitka.v
        ulitka.right, ulitka.left = True, False
        ulitka.standing = False
    else:
        ulitka.standing = True
        ulitka.walkCount = 0

    for o in objects:
        if o.falling == False:
            objects.pop(objects.index(o))
            score += 1

    for p in powerups:
        if p.appear == False:
            powerups.pop(powerups.index(p))

    for r in objects:

        if center_x >= r.hitbox[0] and center_x <= r.hitbox[0] + r.hitbox[2]:

            if center_y >= r.hitbox[1] and center_y <= r.hitbox[1] + r.hitbox[3]:

                if r.id == "VETKA":
                    if ulitka.health - 2 <= 0:
                        ulitka.alive = False
                    else:
                        print("HIT")
                        r.falling = False
                        ulitka.health -= 2
                elif ulitka.health - 1 == 0:
                        ulitka.alive = False
                else:
                    print('hit')
                    r.falling = False
                    ulitka.health -= 1

    x = random.randint(1,10)
    if x >= 5 and len(objects) < 5 + max_length and cooldown >= 20:
        x = random.randint(1, 21)
        xpos = random.randint(0, 500)

        if x == 10 or x == 15:
            smShisk = SmallShishka(xpos, 0)
            objects.append(smShisk)
        elif x == 20:
            vetka = Vetka(xpos, 0)
            objects.append(vetka)
        else:
            Shiska = Shishka(xpos, 0)
            objects.append(Shiska)
        cooldown = 0

    x = random.randint(1, 100)
    if score > 50 and x == 25 and len(powerups) == 0:
        choice = random.randint(1, 100)
        xpos = random.randint(0,500)
        if choice >= 50:
            heart = Grip(xpos)
            powerups.append(heart)

    for p in powerups:
        if center_x >= p.hitbox[0] and center_x <= p.hitbox[0] + p.hitbox[2]:
            if center_y >= p.hitbox[1] and center_y <= p.hitbox[1] + p.hitbox[3]:
                if ulitka.health < 10:
                    ulitka.health = 10

                p.appear = False

    drawWindow()

    if score < 10:
        cooldown += 1
    else:
        cooldown += int(score * 0.1)

run = True

while run and not(ulitka.alive):

    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            run = False

drawWindow()

pygame.quit()